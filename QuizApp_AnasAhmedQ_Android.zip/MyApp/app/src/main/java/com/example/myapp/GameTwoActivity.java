package com.example.myapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GameTwoActivity extends AppCompatActivity {

    private TextView alphabetQuestionTextView;
    private TextView alphabetView;
    private RadioGroup alphabetOptionsRadioGroup;
    private Button submitAlphabetButton;
    private int score = 0;
    private int currentQuestion = 0;
    private String[] alphabets = {"A", "B", "C", "D"};
    private String[] correctAnswers = {"A", "B", "C", "D"}; // Correct options

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_two);

        alphabetQuestionTextView = findViewById(R.id.alphabetQuestionTextView);
        alphabetView = findViewById(R.id.alphabetView);
        alphabetOptionsRadioGroup = findViewById(R.id.alphabetOptionsRadioGroup);
        submitAlphabetButton = findViewById(R.id.submitAlphabetButton);

        loadNextQuestion();

        submitAlphabetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedOption = alphabetOptionsRadioGroup.getCheckedRadioButtonId();
                if (selectedOption == -1) {
                    Toast.makeText(GameTwoActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                } else {
                    int selectedOptionIndex = alphabetOptionsRadioGroup.indexOfChild(findViewById(selectedOption));
                    if (correctAnswers[selectedOptionIndex].equals(correctAnswers[currentQuestion])) {
                        score++;
                    }
                    currentQuestion++;
                    if (currentQuestion < alphabets.length) {
                        loadNextQuestion();
                    } else {
                        saveGameCompletionStatus("GameTwoCompleted");
                        Intent intent = new Intent(GameTwoActivity.this, ScoreActivity.class);
                        intent.putExtra("score", score);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private void loadNextQuestion() {
        if (currentQuestion < alphabets.length) {
            alphabetView.setText(alphabets[currentQuestion]);
            alphabetOptionsRadioGroup.clearCheck();
        }
    }

    private void saveGameCompletionStatus(String gameKey) {
        SharedPreferences sharedPreferences = getSharedPreferences("GameCompletionStatus", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(gameKey, true);
        editor.apply();
    }
}

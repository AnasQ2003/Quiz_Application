package com.example.myapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GameThreeActivity extends AppCompatActivity {

    private TextView objectQuestionTextView;
    private ImageView objectImageView;
    private RadioGroup objectOptionsRadioGroup;
    private Button submitObjectButton;
    private int score = 0;
    private int currentQuestion = 0;
    private int[] objects = {R.drawable.apple, R.drawable.car, R.drawable.house, R.drawable.tree};
    private String[] correctAnswers = {"Apple", "Car", "House", "Tree"}; // Correct options

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_three);

        objectQuestionTextView = findViewById(R.id.objectQuestionTextView);
        objectImageView = findViewById(R.id.objectImageView);
        objectOptionsRadioGroup = findViewById(R.id.objectOptionsRadioGroup);
        submitObjectButton = findViewById(R.id.submitObjectButton);

        loadNextQuestion();

        submitObjectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedOption = objectOptionsRadioGroup.getCheckedRadioButtonId();
                if (selectedOption == -1) {
                    Toast.makeText(GameThreeActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                } else {
                    int selectedOptionIndex = objectOptionsRadioGroup.indexOfChild(findViewById(selectedOption));
                    if (correctAnswers[selectedOptionIndex].equals(correctAnswers[currentQuestion])) {
                        score++;
                    }
                    currentQuestion++;
                    if (currentQuestion < objects.length) {
                        loadNextQuestion();
                    } else {
                        saveGameCompletionStatus("GameThreeCompleted");
                        Intent intent = new Intent(GameThreeActivity.this, ScoreActivity.class);
                        intent.putExtra("score", score);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private void loadNextQuestion() {
        if (currentQuestion < objects.length) {
            objectImageView.setImageResource(objects[currentQuestion]);
            objectOptionsRadioGroup.clearCheck();
        }
    }

    private void saveGameCompletionStatus(String gameKey) {
        SharedPreferences sharedPreferences = getSharedPreferences("GameCompletionStatus", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(gameKey, true);
        editor.apply();
    }
}

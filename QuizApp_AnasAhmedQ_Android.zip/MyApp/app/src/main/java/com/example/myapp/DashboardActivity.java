package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button gameOneButton;
    private Button gameTwoButton;
    private Button gameThreeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        gameOneButton = findViewById(R.id.gameOneButton);
        gameTwoButton = findViewById(R.id.gameTwoButton);
        gameThreeButton = findViewById(R.id.gameThreeButton);

        gameOneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, GameOneActivity.class);
                startActivity(intent);
            }
        });

        gameTwoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, GameTwoActivity.class);
                startActivity(intent);
            }
        });

        gameThreeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, GameThreeActivity.class);
                startActivity(intent);
            }
        });
    }
}

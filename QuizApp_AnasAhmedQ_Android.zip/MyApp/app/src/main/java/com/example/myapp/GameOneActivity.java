package com.example.myapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GameOneActivity extends AppCompatActivity {

    private TextView colorQuestionTextView;
    private RadioGroup colorOptionsRadioGroup;
    private Button submitColorButton;
    private int score = 0;
    private int currentQuestion = 0;
    private String[] colors = {"#FF0000", "#00FF00", "#0000FF", "#FFFF00"};
    private String[] colorNames = {"Red", "Green", "Blue", "Yellow"};
    private int[] correctAnswers = {0, 2, 1, 3}; // Correct options index

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_one);

        colorQuestionTextView = findViewById(R.id.colorQuestionTextView);
        colorOptionsRadioGroup = findViewById(R.id.colorOptionsRadioGroup);
        submitColorButton = findViewById(R.id.submitColorButton);

        loadNextQuestion();

        submitColorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedOption = colorOptionsRadioGroup.getCheckedRadioButtonId();
                if (selectedOption == -1) {
                    Toast.makeText(GameOneActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                } else {
                    int selectedOptionIndex = colorOptionsRadioGroup.indexOfChild(findViewById(selectedOption));
                    if (selectedOptionIndex == correctAnswers[currentQuestion]) {
                        score++;
                    }
                    currentQuestion++;
                    if (currentQuestion < colors.length) {
                        loadNextQuestion();
                    } else {
                        saveGameCompletionStatus("GameOneCompleted");
                        Intent intent = new Intent(GameOneActivity.this, ScoreActivity.class);
                        intent.putExtra("score", score);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private void loadNextQuestion() {
        if (currentQuestion < colors.length) {
            findViewById(R.id.colorView).setBackgroundColor(android.graphics.Color.parseColor(colors[currentQuestion]));
            colorOptionsRadioGroup.clearCheck();
        }
    }

    private void saveGameCompletionStatus(String gameKey) {
        SharedPreferences sharedPreferences = getSharedPreferences("GameCompletionStatus", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(gameKey, true);
        editor.apply();
    }
}

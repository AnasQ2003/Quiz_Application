package com.example.myapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ScoreActivity extends AppCompatActivity {

    private TextView scoreTextView;
    private Button goToDashboardButton;
    private Button quitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        scoreTextView = findViewById(R.id.scoreTextView);
        goToDashboardButton = findViewById(R.id.goToDashboardButton);
        quitButton = findViewById(R.id.quitButton);

        int score = getIntent().getIntExtra("score", 0);
        scoreTextView.setText("Your total score is: " + score);

        goToDashboardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScoreActivity.this, DashboardActivity.class);
                startActivity(intent);
            }
        });

        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAllGamesCompleted()) {
                    Toast.makeText(ScoreActivity.this, "Quitting the app...", Toast.LENGTH_SHORT).show();
                    finishAffinity(); // Closes all activities and quits the app
                } else {
                    Toast.makeText(ScoreActivity.this, "Please complete all games before quitting.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean checkAllGamesCompleted() {
        SharedPreferences sharedPreferences = getSharedPreferences("GameCompletionStatus", MODE_PRIVATE);
        boolean gameOneCompleted = sharedPreferences.getBoolean("GameOneCompleted", false);
        boolean gameTwoCompleted = sharedPreferences.getBoolean("GameTwoCompleted", false);
        boolean gameThreeCompleted = sharedPreferences.getBoolean("GameThreeCompleted", false);

        // Debugging logs to check the completion flags
        System.out.println("Game One Completed: " + gameOneCompleted);
        System.out.println("Game Two Completed: " + gameTwoCompleted);
        System.out.println("Game Three Completed: " + gameThreeCompleted);

        return gameOneCompleted && gameTwoCompleted && gameThreeCompleted;
    }
}
